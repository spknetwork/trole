const Blacklist = []

module.exports = Blacklist